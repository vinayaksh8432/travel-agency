import { difftrain, carbeach, monk } from "../assets";
const looks = [
   {
      image: difftrain,
      click: "CLICK HERE",
      title: "Lorem Ipsum Dolor",
      description:
         "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Lorem, ipsum dolor sit amet consectetur adipisicing elit.",
   },
   {
      image: carbeach,
      click: "CLICK HERE",
      title: "Lorem Ipsum Dolor",
      description:
         "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Lorem, ipsum dolor sit amet consectetur adipisicing elit.",
   },
   {
      image: monk,
      click: "CLICK HERE",
      title: "Lorem Ipsum Dolor",
      description:
         "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Lorem, ipsum dolor sit amet consectetur adipisicing elit.",
   },
];

export { looks };
