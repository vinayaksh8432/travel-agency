import { plane, bank, cook, trainIcon, cycle, eye } from "../assets";

const bestServices = [
   {
      image: plane,
      title: "Lorem Ipsum Dolor sit",
      description:
         "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eismod.",
   },
   {
      image: bank,
      title: "Lorem Ipsum Dolor sit",
      description:
         "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eismod.",
   },
   {
      image: cook,
      title: "Lorem Ipsum Dolor sit",
      description:
         "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eismod.",
   },
   {
      image: trainIcon,
      title: "Lorem Ipsum Dolor sit",
      description:
         "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eismod.",
   },
   {
      image: cycle,
      title: "Lorem Ipsum Dolor sit",
      description:
         "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eismod.",
   },
   {
      image: eye,
      title: "Lorem Ipsum Dolor sit",
      description:
         "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eismod.",
   },
];

export { bestServices };
