import { location1, location2, location3 } from "../assets";

const locations = [
   {
      image: location1,
      days: "7 Day + 6 Night",
      location: "New York + Paris",
      about: "lorem ipsum dolor sit amet, consecutor adipiscing elit.",
      price: "$600",
      click: "BOOK NOW",
   },
   {
      image: location2,
      days: "7 Day + 6 Night",
      location: "New York + Paris",
      about: "lorem ipsum dolor sit amet, consecutor adipiscing elit.",
      price: "$1000",
      click: "BOOK NOW",
   },
   {
      image: location3,
      days: "7 Day + 6 Night",
      location: "New York + Paris",
      about: "lorem ipsum dolor sit amet, consecutor adipiscing elit.",
      price: "$800",
      click: "BOOK NOW",
   },
];

export { locations };
